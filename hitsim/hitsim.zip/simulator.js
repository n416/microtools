// ===============================================
// simulator.js : メイン画面用スクリプト (最終確定仕様・画像表示対応版)
// ===============================================

// --- グローバル定数・変数 ---
const DB_NAME = 'GameEquipmentDB';
const DB_VERSION = 7;
const STORE_NAME = 'equipment';
const INVENTORY_KEY = 'equipmentInventory_v2';
const EQUIPMENT_SET_KEY = 'equipmentSet_v1';

let db;
let equippedItems = {}; 

// [ルールブック1] タイプとスロット種別の紐付け
const TYPE_TO_SLOT_CATEGORY = {
    '01大剣': 'weapon', '02宝珠': 'weapon', '03鈍器': 'weapon', '04弓': 'weapon', 
    '05杖': 'weapon', '06双剣': 'weapon', '07鎌': 'weapon', '08双拳銃': 'weapon', '09御剣': 'weapon',
    '11頭': 'head', '12手': 'hands', '13上装備': 'top', '14下装備': 'bottom', '15足': 'feet',
    '16マント': 'cloak', '21ベルト': 'belt', '22ブレスレット': 'bracelet', '23リング': 'ring',
    '24ネックレス': 'necklace', '25勲章・守護具': 'medal_guardian', '26カンパネラ': 'campanella',
    '27アミュレッタ': 'amulet'
};

// [ルールブック2] スロット種別とHTML要素IDの紐付け
const SLOT_CATEGORY_TO_IDS = {
    'weapon': ['slot-weapon'], 'head': ['slot-head'], 'top': ['slot-top'], 'hands': ['slot-hands'],
    'feet': ['slot-feet'], 'bottom': ['slot-bottom'], 'cloak': ['slot-cloak'], 'belt': ['slot-belt'],
    'necklace': ['slot-necklace'], 'bracelet': ['slot-bracelet'],
    'ring': ['slot-ring1', 'slot-ring2', 'slot-ring3', 'slot-ring4', 'slot-ring5'],
    'medal_guardian': ['slot-medal', 'slot-guardian'], 'amulet': ['slot-amulet'], 'campanella': ['slot-campanella'],
};


// --- 初期化処理 ---
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await openDatabase();
        loadEquippedItems();
        await loadAndRenderInventory();
    } catch (error) {
        console.error('初期化中にエラーが発生しました:', error);
    }
});


// --- 関数定義 ---

function openDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onerror = (e) => reject('DBオープン失敗:', e.target.error);
        request.onsuccess = (e) => { db = e.target.result; resolve(); };
    });
}

async function loadAndRenderInventory() {
    const inventoryItemNames = JSON.parse(localStorage.getItem(INVENTORY_KEY)) || [];
    if (inventoryItemNames.length === 0) {
        document.getElementById('inventory-list').innerHTML = '<p style="padding: 10px;">インベントリにアイテムがありません。<br><a href="data.html">インベントリ編集ページ</a>でアイテムを追加してください。</p>';
        return;
    }
    const itemPromises = inventoryItemNames.map(name => getItemFromDB(name));
    const inventoryItems = (await Promise.all(itemPromises)).filter(item => item);
    renderInventory(inventoryItems);
}

function getItemFromDB(itemName) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const request = transaction.objectStore(STORE_NAME).get(itemName);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = (e) => reject(`アイテム取得エラー: ${e.target.error}`);
    });
}

/**
 * ▼▼▼【変更箇所】▼▼▼
 * インベントリのアイテムリストを画像で描画する
 * @param {Array<object>} items - 描画するアイテムオブジェクトの配列
 */
function renderInventory(items) {
    const inventoryListDiv = document.getElementById('inventory-list');
    inventoryListDiv.innerHTML = ''; 

    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'inventory-item';
        itemDiv.title = `${item['名称']}\nタイプ: ${item['タイプ']}`; // ホバーで名称とタイプ表示
        
        // 画像要素を作成
        const img = document.createElement('img');
        img.src = item['画像URL'] || ''; // 画像URLが空の場合のエラーを防ぐ
        img.alt = item['名称'];
        img.className = 'item-icon';
        img.loading = 'lazy'; // 遅延読み込み

        itemDiv.appendChild(img);
        itemDiv.addEventListener('click', () => equipItem(item));
        inventoryListDiv.appendChild(itemDiv);
    });
}

function equipItem(item) {
    const itemType = item['タイプ'];
    const slotCategory = TYPE_TO_SLOT_CATEGORY[itemType];
    if (!slotCategory) return;

    const possibleSlotIds = SLOT_CATEGORY_TO_IDS[slotCategory];
    let targetSlotId = null;

    for(const slot in equippedItems){
        if(equippedItems[slot] && equippedItems[slot]['名称'] === item['名称']){
            return;
        }
    }

    for (const slotId of possibleSlotIds) {
        if (!equippedItems[slotId]) {
            targetSlotId = slotId;
            break;
        }
    }

    if (!targetSlotId) {
        targetSlotId = possibleSlotIds[0];
    }

    if (equippedItems[targetSlotId]) {
        unequipItem(targetSlotId);
    }

    equippedItems[targetSlotId] = item;
    renderSlot(targetSlotId);
    saveEquippedItems();
}

function unequipItem(slotId) {
    if (equippedItems[slotId]) {
        delete equippedItems[slotId];
        renderSlot(slotId);
        saveEquippedItems();
    }
}

/**
 * ▼▼▼【変更箇所】▼▼▼
 * 指定されたスロットの表示を更新する（画像表示対応）
 * @param {string} slotId - 描画するスロットのID
 */
function renderSlot(slotId) {
    const slotElement = document.getElementById(slotId);
    if (!slotElement) return;

    slotElement.innerHTML = ''; // 一旦クリア
    const item = equippedItems[slotId];

    if (item) {
        // 装備している場合
        slotElement.title = `${item['名称']}\nタイプ: ${item['タイプ']}`;
        const img = document.createElement('img');
        img.src = item['画像URL'] || '';
        img.alt = item['名称'];
        img.className = 'item-icon';

        const unequipButton = document.createElement('button');
        unequipButton.className = 'unequip-button';
        unequipButton.textContent = '×';
        unequipButton.title = "外す";
        unequipButton.onclick = (e) => {
            e.stopPropagation();
            unequipItem(slotId);
        };
        
        slotElement.appendChild(img);
        slotElement.appendChild(unequipButton);

    } else {
        // 装備していない場合（デフォルトの表示）
        slotElement.title = '';
        const defaultSpan = document.createElement('span');
        const slotName = slotElement.id.replace('slot-', '');
        // リングとだけ表示すると分かりにくいので番号をつける
        defaultSpan.textContent = slotName.startsWith('ring') ? slotName : slotName.charAt(0).toUpperCase() + slotName.slice(1);
        slotElement.appendChild(defaultSpan);
    }
}

function saveEquippedItems() {
    const savableData = {};
    for (const slotId in equippedItems) {
        savableData[slotId] = equippedItems[slotId]['名称'];
    }
    localStorage.setItem(EQUIPMENT_SET_KEY, JSON.stringify(savableData));
}

async function loadEquippedItems() {
    const savedSet = JSON.parse(localStorage.getItem(EQUIPMENT_SET_KEY)) || {};
    const itemPromises = [];

    for (const slotId in savedSet) {
        const itemName = savedSet[slotId];
        itemPromises.push(
            getItemFromDB(itemName).then(item => {
                if (item) {
                    equippedItems[slotId] = item;
                }
            })
        );
    }
    await Promise.all(itemPromises);
    
    document.querySelectorAll('.slot').forEach(slotElement => {
        renderSlot(slotElement.id);
    });
}